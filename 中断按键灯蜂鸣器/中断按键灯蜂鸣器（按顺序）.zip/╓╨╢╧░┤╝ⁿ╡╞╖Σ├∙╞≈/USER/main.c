#include "sys.h"
#include "delay.h"
#include "led.h"
#include "beep.h"
#include "exti.h"

extern volatile uint8_t key0_flag;
extern volatile uint8_t key1_flag;
extern volatile uint8_t key2_flag;
extern volatile uint8_t wkup_flag;

int main(void)
{
    uint8_t i, j;
    uint8_t beep_state = 0;

    delay_init(168);
    LED_Init();
    BEEP_Init();
    EXTIX_Init();

    while(1)
    {
        // ================= KEY0 =================
        if(key0_flag)
        {
            key0_flag = 0;
            for(j=0; j<5; j++)
            {
                // ������˸5��
                for(i=0; i<5; i++)
                {
                    GPIO_SetBits(GPIOF, GPIO_Pin_9);
                    GPIO_ResetBits(GPIOF, GPIO_Pin_10);
                    delay_ms(200);

                    GPIO_ResetBits(GPIOF, GPIO_Pin_9);
                    GPIO_SetBits(GPIOF, GPIO_Pin_10);
                    delay_ms(200);
                }
                // ȫ��
                GPIO_ResetBits(GPIOF, GPIO_Pin_9 | GPIO_Pin_10);
                delay_ms(500);
            }
            // ȫ��
            GPIO_SetBits(GPIOF, GPIO_Pin_9 | GPIO_Pin_10);
        }

        // ================= KEY1 DS0��10�� =================
        if(key1_flag)
        {
            key1_flag = 0;
            for(i=0; i<10; i++)
            {
                GPIO_SetBits(GPIOF, GPIO_Pin_9);
                delay_ms(200);
                GPIO_ResetBits(GPIOF, GPIO_Pin_9);
                delay_ms(200);
            }
						 GPIO_SetBits(GPIOF, GPIO_Pin_9 | GPIO_Pin_10);
        }

        // ================= KEY2 DS1��10�� =================
        if(key2_flag)
        {
            key2_flag = 0;
            for(i=0; i<10; i++)
            {
                GPIO_SetBits(GPIOF, GPIO_Pin_10);
                delay_ms(200);
                GPIO_ResetBits(GPIOF, GPIO_Pin_10);
                delay_ms(200);
            }
						 GPIO_SetBits(GPIOF, GPIO_Pin_9 | GPIO_Pin_10);
        }

        // ================= WK_UP ������ =================
        if(wkup_flag)
        {
            wkup_flag = 0;
            beep_state = !beep_state;
            if(beep_state)
                GPIO_SetBits(GPIOF, GPIO_Pin_8);
            else
                GPIO_ResetBits(GPIOF, GPIO_Pin_8);
        }
    }
}