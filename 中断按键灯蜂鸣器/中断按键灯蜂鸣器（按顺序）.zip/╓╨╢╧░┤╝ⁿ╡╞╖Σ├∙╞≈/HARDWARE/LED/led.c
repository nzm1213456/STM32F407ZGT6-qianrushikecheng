//#include "led.h"

//void LED_Init(void)
//{

//    GPIO_InitTypeDef GPIO_InitStruct;

//    
//    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);

//    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
//    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
//    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
//    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
//    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;

//    GPIO_Init(GPIOF, &GPIO_InitStruct);


//    GPIO_SetBits(GPIOF, GPIO_Pin_9 | GPIO_Pin_10);
//}
#include "led.h"

// LED??? PF9 PF10
void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    // ?GPIOF??
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);

    // PF9 PF10 ????
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOF, &GPIO_InitStructure);

    // ????
    GPIO_SetBits(GPIOF, GPIO_Pin_9 | GPIO_Pin_10);
}





