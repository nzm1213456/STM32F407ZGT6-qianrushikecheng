#include "key.h"
#include "delay.h"

//////////////////////////////////////////////////////////////////////////////////
//?????????,??????,??????????
//ALIENTEK STM32F407???
//????????
//????@ALIENTEK
//????:www.openedv.com
//????:2014/5/3
//??:V1.0
//????,?????
//Copyright(C)????????????? 2014-2024
//All rights reserved
//////////////////////////////////////////////////////////////////////////////////

//???????
void KEY_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOE,ENABLE); //??GPIOA,GPIOE??

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4; //KEY0-KEY2????
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;                    //????
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;                    //??
    GPIO_Init(GPIOE, &GPIO_InitStructure);                           //???

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;                        //WK_UP????PA0
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;                   //??
    GPIO_Init(GPIOA, &GPIO_InitStructure);                           //???
}

//??????
//mode:0,??????;1,?????
//???:0,????????
//        KEY0_PRES,KEY0??
//        KEY1_PRES,KEY1??
//        KEY2_PRES,KEY2??
//        WKUP_PRES,WK_UP??
u8 KEY_Scan(u8 mode)
{
    static u8 key_up=1; //??????
    if(mode)key_up=1;   //????

    if(key_up&&(KEY0==0||KEY1==0||KEY2==0||WK_UP==1))
    {
        delay_ms(10); //??
        key_up=0;

        if(KEY0==0)       return KEY0_PRES;
        else if(KEY1==0)  return KEY1_PRES;
        else if(KEY2==0)  return KEY2_PRES;
        else if(WK_UP==1) return WKUP_PRES;
    }
    else if(KEY0==1&&KEY1==1&&KEY2==0&&WK_UP==0)
        key_up=1;

    return 0; //?????
}
