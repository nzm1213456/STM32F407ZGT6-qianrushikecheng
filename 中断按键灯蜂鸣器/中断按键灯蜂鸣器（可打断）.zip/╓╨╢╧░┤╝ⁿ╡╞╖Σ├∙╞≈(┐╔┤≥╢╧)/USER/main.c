#include "stm32f4xx.h"
#include "led.h"
#include "key.h"
#include "exti.h"
#include "beep.h"
#include "delay.h"
#include "breath.h"
#include "sys.h"

// �ⲿ�жϱ�־λ
extern volatile uint8_t key0_flag;
extern volatile uint8_t key1_flag;
extern volatile uint8_t key2_flag;
extern volatile uint8_t wkup_flag;

u8 beep_state = 0; // ������״̬ 0�ر� 1����

int main(void)
{
    u8 loop;
    u8 i;

    // ��ʼ��
    delay_init(168);
    LED_Init();
    BEEP_Init();
    EXTIX_Init();

    while(1)
    {
        //  ===================== ����(������) =====================
        Breath_Run();

        // ===================== KEY0 =====================
        if(key0_flag == 1)
        {
            key0_flag = 0;
            for(loop=0; loop<5; loop++)
            {
                for(i=0; i<5; i++)
                {
                    if(key1_flag || key2_flag || wkup_flag) goto exit_key0;

                    GPIO_SetBits(GPIOF, GPIO_Pin_9);
                    GPIO_ResetBits(GPIOF, GPIO_Pin_10);
                    delay_ms(200);

                    if(key1_flag || key2_flag || wkup_flag) goto exit_key0;

                    GPIO_ResetBits(GPIOF, GPIO_Pin_9);
                    GPIO_SetBits(GPIOF, GPIO_Pin_10);
                    delay_ms(200);
                }
                GPIO_ResetBits(GPIOF, GPIO_Pin_9 | GPIO_Pin_10);
                delay_ms(500);
            }
            exit_key0:;
        }

        // ===================== KEY1 =====================
        if(key1_flag == 1)
        {
            key1_flag = 0;
            for(i=0; i<10; i++)
            {
                if(key0_flag || key2_flag || wkup_flag) goto exit_key1;

                GPIO_ResetBits(GPIOF, GPIO_Pin_9);
								GPIO_SetBits(GPIOF, GPIO_Pin_10);
                delay_ms(200);
                if(key0_flag || key2_flag || wkup_flag) goto exit_key1;
                GPIO_SetBits(GPIOF, GPIO_Pin_9);
								GPIO_SetBits(GPIOF, GPIO_Pin_10);
                delay_ms(200);
            }
            exit_key1:;
        }

        // ===================== KEY2 =====================
        if(key2_flag == 1)
        {
            key2_flag = 0;
            for(i=0; i<10; i++)
            {
                if(key0_flag || key1_flag || wkup_flag) goto exit_key2;

                GPIO_ResetBits(GPIOF, GPIO_Pin_10);
								GPIO_SetBits(GPIOF, GPIO_Pin_9);
                delay_ms(200);
                if(key0_flag || key1_flag || wkup_flag) goto exit_key2;
                GPIO_SetBits(GPIOF, GPIO_Pin_10);
								GPIO_SetBits(GPIOF, GPIO_Pin_9);
                delay_ms(200);
            }
            exit_key2:;
        }

        // ===================== WK_UP =====================
       if(wkup_flag == 1)
        {
            wkup_flag = 0;       // ���־
            delay_ms(20);        // ����
            if(WK_UP == 1)
            {
                beep_state = !beep_state;
                if(beep_state)
                    GPIO_ResetBits(GPIOF, GPIO_Pin_8);   // ��
                else
                    GPIO_SetBits(GPIOF, GPIO_Pin_8);     // ��
						}	
				}
    }
}