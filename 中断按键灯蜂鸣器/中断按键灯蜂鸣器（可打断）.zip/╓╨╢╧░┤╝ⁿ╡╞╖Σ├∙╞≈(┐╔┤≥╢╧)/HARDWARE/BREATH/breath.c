#include "breath.h"
#include "delay.h"
#include "led.h"

void Breath_Run(void)
{
    static int16_t bright = 0;
    static int8_t dir = 1;
    
    bright += dir;
    if(bright >= 100) dir = -1;
    if(bright <= 0)   dir = 1;
    
    if(bright > 50)
    {
        GPIO_ResetBits(GPIOF, GPIO_Pin_9 | GPIO_Pin_10);
    }
    else
    {
        GPIO_SetBits(GPIOF, GPIO_Pin_9 | GPIO_Pin_10);
    }
    // ��ʱ�ĳ�5ms���ٶȱ���
    delay_ms(5);
}