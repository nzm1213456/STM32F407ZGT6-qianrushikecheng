#ifndef __LED_H
#define __LED_H

#include "stm32f4xx.h"

#define LED1    PFout(9)   // DS1
#define LED2    PFout(10)  // DS0

void LED_Init(void);

#endif
