#ifndef _TIME_H
#define _TIME_H

#include "stm32f4xx.h"
#include "stm32f4xx_tim.h"
#include "sys.h"

void TIM2_Int_Init(u16 arr, u16 psc);
void TIM3_Int_Init(u16 arr, u16 psc);
void TIM5_Int_Init(u16 arr, u16 psc);

#endif
