#include "stm32f4xx.h"
#include "sys.h"
#include "led.h"
#include "beep.h"
#include "time.h"

int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    LED_Init();
    BEEP_Init();

    TIM2_Int_Init(3999, 8399);		// 400ms: (3999+1)*(8399+1)/84M = 0.4s
    TIM3_Int_Init(4999, 8399);    // 500ms: (4999+1)*(8399+1)/84M = 0.5s
    TIM5_Int_Init(9999, 8399);    // 1000ms: (9999+1)*(8399+1)/84M = 1s

    while(1)
    {
			
    }
}
